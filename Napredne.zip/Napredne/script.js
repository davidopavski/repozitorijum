var cards = [
  {
    ime:"Cristiano Messi",
    drzava:"Argentina",
    cena:340000,
    rarity:"common"
  },
  {
    ime:"Cristiano Ronaldo",
    drzava:"Portugal",
    cena:620000,
    rarity:"rare"
  },
  {
    ime:"Angel Di Maria",
    drzava:"Argentina",
    cena:17000,
    rarity:"legendary"
  }
]
var filteredCards=cards;
document.getElementById("search-box").addEventListener("change",()=> {
  filteredCards = cards.filter(card => card.ime.includes(document.getElementById("search-box").value));
  generateCards(filteredCards);
})

function addNewCard(){
  // cards.push({
  //   ime:document.getElementById("new-ime").value,
  //   drzava:document.getElementById("new-drzava").value,
  //   cena:parseInt(document.getElementById("new-cena").value)
  // })
  filteredCards.push({
    ime:document.getElementById("new-ime").value,
    drzava:document.getElementById("new-drzava").value,
    cena:parseInt(document.getElementById("new-cena").value)
  })
  generateCards(filteredCards)
}
document.getElementById("sortirajOpcije").addEventListener("change", ()=> {
  var filteredCards;
  switch(document.getElementById("sortirajOpcije").value){
    case "cena rastuce":
        sortCards(0)
        break;
    case "cena opadajuce":
        sortCards(1);
        break;
      default:
        break;
    
  }
})

function sortCards(order) {
  if(order == 0) {
    filteredCards.sort((a,b) => {
      if(a.cena > b.cena){
        return 1
      }
      else{
        return -1;
      }
    })
  }
  if(order == 1) {
    filteredCards.sort((a,b) => {
      if(a.cena < b.cena){
        return 1
      }
      else{
        return -1;
      }
    })
  }
  generateCards(filteredCards)
}

function generateCards(arr) {
  document.getElementById("cards-container").innerHTML="";
  arr.forEach(element => {
    document.getElementById("cards-container").innerHTML+= `<div class="football-card">
    <img src="fudbaler.jpg" alt="" class="card-img">
    <div id="card-ime">${element.ime}</div>
    <div id="card-cena">${element.cena}</div>
    <div id="card-drzava">${element.drzava}</div>
</div>`
  });
}
generateCards(cards);


IMAGE_ARRAY = [];
            const image_input = document.querySelector("#image-input");
            image_input.addEventListener("change", function () {
                const reader = new FileReader();
                reader.addEventListener("load", () => {
                    const uploaded_image = reader.result;
                    IMAGE_ARRAY.push(uploaded_image);
                    document.querySelector("#display-image").style.backgroundImage = `url(${uploaded_image})`;
                });
                reader.readAsDataURL(this.files[0]);
            });
    
            function AddImage(){
                document.querySelector("#all-images").innerHTML = "";
                IMAGE_ARRAY.forEach(element => {
                    console.log(element)
                    let d = document.createElement("div");
                    d.className = "display-image"
                    d.style.backgroundImage = `url(${element})`;
                    document.querySelector("#all-images").append(d);
                });
            }

            